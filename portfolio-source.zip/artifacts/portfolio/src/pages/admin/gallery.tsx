import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useListGalleryPhotos, 
  useCreateGalleryPhoto, 
  useDeleteGalleryPhoto,
  getListGalleryPhotosQueryKey,
  getGetSiteStatsQueryKey
} from "@workspace/api-client-react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ImageUploader } from "@/components/image-uploader";
import { Plus, Trash2, Image as ImageIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminGallery() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { data: photos, isLoading } = useListGalleryPhotos();
  const createPhoto = useCreateGalleryPhoto();
  const deletePhoto = useDeleteGalleryPhoto();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    imageUrl: "",
    caption: "",
    altText: "",
  });

  const resetForm = () => {
    setFormData({
      imageUrl: "",
      caption: "",
      altText: "",
    });
  };

  const handleDeleteClick = (id: number) => {
    setDeletingId(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!deletingId) return;
    try {
      await deletePhoto.mutateAsync({ id: deletingId });
      queryClient.invalidateQueries({ queryKey: getListGalleryPhotosQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetSiteStatsQueryKey() });
      toast({ title: "Success", description: "Photo deleted successfully" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete photo", variant: "destructive" });
    } finally {
      setIsDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.imageUrl) {
      toast({ title: "Error", description: "Please provide an image URL", variant: "destructive" });
      return;
    }

    try {
      await createPhoto.mutateAsync({ data: formData });
      toast({ title: "Success", description: "Photo added successfully" });
      queryClient.invalidateQueries({ queryKey: getListGalleryPhotosQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetSiteStatsQueryKey() });
      setIsFormOpen(false);
      resetForm();
    } catch (error) {
      toast({ title: "Error", description: "Failed to save photo", variant: "destructive" });
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Gallery</h2>
            <p className="text-muted-foreground">Manage your photo gallery.</p>
          </div>
          <Button onClick={() => { resetForm(); setIsFormOpen(true); }}>
            <Plus className="w-4 h-4 mr-2" /> Add Photo
          </Button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="aspect-square rounded-xl" />
            ))}
          </div>
        ) : photos?.length ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {photos.map((photo) => (
              <Card key={photo.id} className="overflow-hidden group border-border/50 relative">
                <div className="aspect-square bg-muted relative">
                  <img src={photo.imageUrl} alt={photo.altText || ""} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4 text-white">
                    <p className="text-sm font-medium truncate">{photo.caption}</p>
                    <div className="absolute top-2 right-2">
                      <Button variant="destructive" size="icon" className="h-8 w-8 rounded-full" onClick={() => handleDeleteClick(photo.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-dashed bg-transparent">
            <CardContent className="flex flex-col items-center justify-center p-12 text-center">
              <ImageIcon className="w-12 h-12 text-muted-foreground mb-4 opacity-20" />
              <p className="text-lg font-medium">No photos yet</p>
              <p className="text-muted-foreground mb-4">Add your first photo to the gallery.</p>
              <Button onClick={() => { resetForm(); setIsFormOpen(true); }} variant="outline">
                Add Photo
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Form Dialog */}
        <Dialog open={isFormOpen} onOpenChange={(open) => !open && setIsFormOpen(false)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Gallery Photo</DialogTitle>
              <DialogDescription>Upload an image or paste a URL.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6 pt-4">
              <ImageUploader 
                imageUrl={formData.imageUrl} 
                onUploadComplete={(url) => setFormData({ ...formData, imageUrl: url })} 
                label="Photo Image"
              />
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Caption</Label>
                  <Input 
                    value={formData.caption} 
                    onChange={e => setFormData({ ...formData, caption: e.target.value })} 
                    placeholder="E.g., Event at School"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Alt Text</Label>
                  <Input 
                    value={formData.altText} 
                    onChange={e => setFormData({ ...formData, altText: e.target.value })} 
                    placeholder="Description for screen readers"
                  />
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)}>Cancel</Button>
                <Button type="submit">Add Photo</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the photo from your gallery.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setDeletingId(null)}>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}