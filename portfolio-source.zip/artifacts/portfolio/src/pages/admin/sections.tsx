import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { LayoutTemplate } from "lucide-react";

const SECTIONS = [
  { id: "Hero", label: "Hero Section", description: "The main landing area with your introduction." },
  { id: "About Me", label: "About Me", description: "Brief description of who you are." },
  { id: "Skills", label: "Skills & Expertise", description: "Grid of your technical and soft skills." },
  { id: "Goals", label: "Goals & Learning", description: "Your current learning objectives." },
  { id: "Latest Posts", label: "Latest Writing", description: "Recent blog posts showcase." },
  { id: "Featured Projects", label: "Featured Projects", description: "Recent projects showcase." },
  { id: "Contact CTA", label: "Contact Call-to-Action", description: "Bottom section encouraging visitors to reach out." }
];

export default function AdminSections() {
  const { toast } = useToast();
  const [sections, setSections] = useState<Record<string, boolean>>({});
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("visible_sections");
    if (saved) {
      try {
        setSections(JSON.parse(saved));
      } catch (e) {
        // Init default all true
        const defaults = SECTIONS.reduce((acc, s) => ({ ...acc, [s.id]: true }), {});
        setSections(defaults);
      }
    } else {
      const defaults = SECTIONS.reduce((acc, s) => ({ ...acc, [s.id]: true }), {});
      setSections(defaults);
    }
    setMounted(true);
  }, []);

  const handleToggle = (id: string, checked: boolean) => {
    const newSections = { ...sections, [id]: checked };
    setSections(newSections);
    localStorage.setItem("visible_sections", JSON.stringify(newSections));
    
    toast({
      title: "Settings Saved",
      description: `${id} is now ${checked ? 'visible' : 'hidden'} on the homepage.`,
    });
  };

  if (!mounted) return null;

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-4xl">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-3 bg-primary/10 text-primary rounded-xl">
            <LayoutTemplate className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Page Sections</h2>
            <p className="text-muted-foreground">Toggle visibility of homepage sections.</p>
          </div>
        </div>

        <Card className="bg-card/50 backdrop-blur-sm border-border/50">
          <CardContent className="p-0">
            <div className="divide-y divide-border/50">
              {SECTIONS.map((section) => (
                <div key={section.id} className="flex items-center justify-between p-6">
                  <div className="space-y-1 pr-6">
                    <Label className="text-base font-semibold">{section.label}</Label>
                    <p className="text-sm text-muted-foreground">{section.description}</p>
                  </div>
                  <Switch 
                    checked={sections[section.id] !== false} 
                    onCheckedChange={(checked) => handleToggle(section.id, checked)}
                  />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}