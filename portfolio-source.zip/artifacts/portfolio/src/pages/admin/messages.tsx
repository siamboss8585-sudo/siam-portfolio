import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useListContactMessages, getListContactMessagesQueryKey } from "@workspace/api-client-react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { MessageSquare, Calendar, User, Mail } from "lucide-react";
import type { ContactMessage } from "@workspace/api-client-react";

export default function AdminMessages() {
  const { data: messages, isLoading } = useListContactMessages();
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Messages</h2>
            <p className="text-muted-foreground">View contact form submissions.</p>
          </div>
        </div>

        <Card className="bg-card/50 backdrop-blur-sm border-border/50">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Date</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Message Preview</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-64" /></TableCell>
                    </TableRow>
                  ))
                ) : messages?.length ? (
                  messages.map((message) => (
                    <TableRow 
                      key={message.id} 
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => setSelectedMessage(message)}
                    >
                      <TableCell className="whitespace-nowrap">
                        {new Date(message.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="font-medium">{message.name}</TableCell>
                      <TableCell>{message.subject}</TableCell>
                      <TableCell className="max-w-md truncate text-muted-foreground">
                        {message.message}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                      No messages found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={!!selectedMessage} onOpenChange={(open) => !open && setSelectedMessage(null)}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-primary" />
                Message Details
              </DialogTitle>
              <DialogDescription>
                Received on {selectedMessage && new Date(selectedMessage.createdAt).toLocaleString()}
              </DialogDescription>
            </DialogHeader>
            
            {selectedMessage && (
              <div className="space-y-6 pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <span className="text-xs text-muted-foreground flex items-center gap-1"><User className="w-3 h-3"/> Name</span>
                    <p className="font-medium">{selectedMessage.name}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="text-xs text-muted-foreground flex items-center gap-1"><Mail className="w-3 h-3"/> Email</span>
                    <p className="font-medium">
                      <a href={`mailto:${selectedMessage.email}`} className="text-primary hover:underline">{selectedMessage.email}</a>
                    </p>
                  </div>
                  <div className="space-y-1 col-span-2">
                    <span className="text-xs text-muted-foreground">Subject</span>
                    <p className="font-medium border p-2 rounded-md bg-muted/30">{selectedMessage.subject}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <span className="text-xs text-muted-foreground">Message Body</span>
                  <div className="p-4 rounded-md bg-muted/30 whitespace-pre-wrap border border-border/50 text-sm leading-relaxed">
                    {selectedMessage.message}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}