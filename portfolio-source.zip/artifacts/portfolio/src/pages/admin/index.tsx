import { useGetSiteStats, useListContactMessages } from "@workspace/api-client-react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Briefcase, Files, Image as ImageIcon, Clock, MessageSquare } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";

export default function AdminDashboard() {
  const { data: stats, isLoading: statsLoading } = useGetSiteStats();
  const { data: messages, isLoading: messagesLoading } = useListContactMessages();

  const statCards = [
    { title: "Blog Posts", value: stats?.totalBlogPosts || 0, icon: FileText, color: "text-blue-500", href: "/admin/blog" },
    { title: "Projects", value: stats?.totalProjects || 0, icon: Briefcase, color: "text-purple-500", href: "/admin/projects" },
    { title: "Documents", value: stats?.totalDocuments || 0, icon: Files, color: "text-orange-500", href: "/admin/documents" },
    { title: "Gallery Photos", value: stats?.totalGalleryPhotos || 0, icon: ImageIcon, color: "text-cyan-500", href: "/admin/gallery" },
    { title: "Timeline Items", value: stats?.totalTimelineItems || 0, icon: Clock, color: "text-green-500", href: "/admin/timeline" },
    { title: "Messages", value: messages?.length || 0, icon: MessageSquare, color: "text-rose-500", href: "/admin/messages" },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight mb-2">Overview</h2>
          <p className="text-muted-foreground">Here's a summary of your website's content.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {statsLoading || messagesLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-4 w-4 rounded-full" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-10 w-16" />
                </CardContent>
              </Card>
            ))
          ) : (
            statCards.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <Link key={i} href={stat.href}>
                  <Card className="hover:border-primary/50 transition-colors cursor-pointer bg-card/50 backdrop-blur-sm border-border/50">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium text-muted-foreground">
                        {stat.title}
                      </CardTitle>
                      <Icon className={`w-4 h-4 ${stat.color}`} />
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold">{stat.value}</div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Recent Posts</CardTitle>
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <div className="space-y-4">
                  {[1,2,3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
                </div>
              ) : stats?.recentPosts?.length ? (
                <div className="space-y-4">
                  {stats.recentPosts.slice(0, 5).map(post => (
                    <div key={post.id} className="flex justify-between items-center border-b border-border/50 pb-4 last:border-0 last:pb-0">
                      <div>
                        <p className="font-medium">{post.title}</p>
                        <p className="text-sm text-muted-foreground">{new Date(post.createdAt).toLocaleDateString()}</p>
                      </div>
                      <Badge variant={post.featured ? "default" : "secondary"}>{post.category}</Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground py-4 text-center">No posts found.</p>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Recent Projects</CardTitle>
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <div className="space-y-4">
                  {[1,2,3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
                </div>
              ) : stats?.recentProjects?.length ? (
                <div className="space-y-4">
                  {stats.recentProjects.slice(0, 5).map(project => (
                    <div key={project.id} className="flex justify-between items-center border-b border-border/50 pb-4 last:border-0 last:pb-0">
                      <div>
                        <p className="font-medium">{project.title}</p>
                        <div className="flex gap-2 mt-1">
                          {project.technologies.slice(0, 3).map(tech => (
                            <Badge key={tech} variant="outline" className="text-xs">{tech}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground py-4 text-center">No projects found.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}