import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useListTimelineItems, 
  useCreateTimelineItem, 
  useDeleteTimelineItem,
  getListTimelineItemsQueryKey,
  getGetSiteStatsQueryKey
} from "@workspace/api-client-react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Plus, Trash2, Clock, Award, Star, BookOpen } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type TimelineItemType = "milestone" | "achievement" | "certification" | "project";

export default function AdminTimeline() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { data: timelineItems, isLoading } = useListTimelineItems();
  const createTimelineItem = useCreateTimelineItem();
  const deleteTimelineItem = useDeleteTimelineItem();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    title: string;
    description: string;
    date: string;
    type: TimelineItemType;
    icon: string;
  }>({
    title: "",
    description: "",
    date: "",
    type: "milestone",
    icon: ""
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      date: "",
      type: "milestone",
      icon: ""
    });
  };

  const handleDeleteClick = (id: number) => {
    setDeletingId(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!deletingId) return;
    try {
      await deleteTimelineItem.mutateAsync({ id: deletingId });
      queryClient.invalidateQueries({ queryKey: getListTimelineItemsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetSiteStatsQueryKey() });
      toast({ title: "Success", description: "Item deleted successfully" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete item", variant: "destructive" });
    } finally {
      setIsDeleteDialogOpen(false);
      setDeletingId(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createTimelineItem.mutateAsync({ data: formData });
      toast({ title: "Success", description: "Item added successfully" });
      queryClient.invalidateQueries({ queryKey: getListTimelineItemsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetSiteStatsQueryKey() });
      setIsFormOpen(false);
      resetForm();
    } catch (error) {
      toast({ title: "Error", description: "Failed to add item", variant: "destructive" });
    }
  };

  const getTypeIcon = (type: string) => {
    switch(type) {
      case "achievement": return <Award className="w-4 h-4 text-purple-500" />;
      case "certification": return <BookOpen className="w-4 h-4 text-blue-500" />;
      case "project": return <Star className="w-4 h-4 text-cyan-500" />;
      default: return <Clock className="w-4 h-4 text-primary" />;
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Timeline</h2>
            <p className="text-muted-foreground">Manage your journey and milestones.</p>
          </div>
          <Button onClick={() => { resetForm(); setIsFormOpen(true); }}>
            <Plus className="w-4 h-4 mr-2" /> Add Milestone
          </Button>
        </div>

        <Card className="bg-card/50 backdrop-blur-sm border-border/50">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Date</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-48" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-64" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-16 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : timelineItems?.length ? (
                  timelineItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-mono text-sm whitespace-nowrap">{item.date}</TableCell>
                      <TableCell className="font-medium">{item.title}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm capitalize text-muted-foreground">
                          {getTypeIcon(item.type)}
                          {item.type}
                        </div>
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-muted-foreground">{item.description}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDeleteClick(item.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                      No timeline items found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Form Dialog */}
        <Dialog open={isFormOpen} onOpenChange={(open) => !open && setIsFormOpen(false)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Timeline Item</DialogTitle>
              <DialogDescription>Add a new milestone to your journey.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Date Label</Label>
                  <Input 
                    value={formData.date} 
                    onChange={e => setFormData({ ...formData, date: e.target.value })} 
                    placeholder="e.g. 2024 or Jun 2024"
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select value={formData.type} onValueChange={(v: TimelineItemType) => setFormData({ ...formData, type: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="milestone">Milestone</SelectItem>
                      <SelectItem value="achievement">Achievement</SelectItem>
                      <SelectItem value="certification">Certification</SelectItem>
                      <SelectItem value="project">Project</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Title</Label>
                <Input 
                  value={formData.title} 
                  onChange={e => setFormData({ ...formData, title: e.target.value })} 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea 
                  value={formData.description} 
                  onChange={e => setFormData({ ...formData, description: e.target.value })} 
                  rows={3} 
                  required
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)}>Cancel</Button>
                <Button type="submit">Add Item</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the timeline item.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setDeletingId(null)}>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}