import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { PenTool, Plus, Trash2, Save, RefreshCw, User, Target, Zap, Info } from "lucide-react";

interface HomeContent {
  hero: {
    name: string;
    tagline: string;
    subtitle: string;
    avatarText: string;
    avatarImageUrl: string;
  };
  about: {
    text: string;
  };
  skills: { name: string }[];
  goals: { label: string; desc: string }[];
}

const DEFAULT_CONTENT: HomeContent = {
  hero: {
    name: "Mojahid Ahammed Siam",
    tagline: "Class 9 Business Studies Student",
    subtitle: "Student · Technology Enthusiast · Digital Learner",
    avatarText: "MAS",
    avatarImageUrl: "",
  },
  about: {
    text: "Hello! I am Mojahid Ahammed Siam, a Class 9 Business Studies student passionate about technology, digital skills, and continuous learning.",
  },
  skills: [
    { name: "Programming" },
    { name: "Coding" },
    { name: "Cybersecurity" },
    { name: "Video Editing" },
    { name: "Digital Tools" },
    { name: "Content Creation" },
    { name: "Business Studies" },
    { name: "Communication" },
  ],
  goals: [
    { label: "Financial Independence", desc: "Building skills to create my own income." },
    { label: "Strong Personal Brand", desc: "Becoming recognizable in technology & digital skills." },
    { label: "Technology Expertise", desc: "Deep knowledge across cybersecurity, coding, and tools." },
    { label: "Continuous Learning", desc: "Never stopping — always growing, always improving." },
    { label: "Meaningful Projects", desc: "Creating things that matter and help others." },
  ],
};

async function fetchContent(): Promise<Record<string, string>> {
  const res = await fetch("/api/content");
  if (!res.ok) return {};
  return res.json();
}

async function saveContent(content: HomeContent): Promise<void> {
  const res = await fetch("/api/content/home_content", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ value: JSON.stringify(content) }),
  });
  if (!res.ok) throw new Error("Failed to save content");
}

export default function AdminContent() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [content, setContent] = useState<HomeContent>(DEFAULT_CONTENT);

  const { data: rawContent, isLoading } = useQuery({
    queryKey: ["site-content"],
    queryFn: fetchContent,
  });

  useEffect(() => {
    if (rawContent?.home_content) {
      try {
        const parsed = JSON.parse(rawContent.home_content) as HomeContent;
        setContent({ ...DEFAULT_CONTENT, ...parsed });
      } catch {
        // keep default
      }
    }
  }, [rawContent]);

  const mutation = useMutation({
    mutationFn: saveContent,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["site-content"] });
      toast({
        title: "Changes Saved!",
        description: "Your homepage has been updated. Visitors will see the new content immediately.",
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Could not save changes. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => mutation.mutate(content);

  const updateHero = (field: keyof HomeContent["hero"], value: string) => {
    setContent((prev) => ({ ...prev, hero: { ...prev.hero, [field]: value } }));
  };

  const updateAbout = (value: string) => {
    setContent((prev) => ({ ...prev, about: { text: value } }));
  };

  const addSkill = () => {
    setContent((prev) => ({ ...prev, skills: [...prev.skills, { name: "New Skill" }] }));
  };

  const updateSkill = (index: number, name: string) => {
    setContent((prev) => {
      const skills = [...prev.skills];
      skills[index] = { name };
      return { ...prev, skills };
    });
  };

  const removeSkill = (index: number) => {
    setContent((prev) => ({ ...prev, skills: prev.skills.filter((_, i) => i !== index) }));
  };

  const addGoal = () => {
    setContent((prev) => ({ ...prev, goals: [...prev.goals, { label: "New Goal", desc: "Description here." }] }));
  };

  const updateGoal = (index: number, field: "label" | "desc", value: string) => {
    setContent((prev) => {
      const goals = [...prev.goals];
      goals[index] = { ...goals[index], [field]: value };
      return { ...prev, goals };
    });
  };

  const removeGoal = (index: number) => {
    setContent((prev) => ({ ...prev, goals: prev.goals.filter((_, i) => i !== index) }));
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64 text-muted-foreground">
          <RefreshCw className="w-6 h-6 animate-spin mr-3" />
          Loading page content...
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="max-w-4xl space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary/10 text-primary rounded-xl">
              <PenTool className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Page Editor</h2>
              <p className="text-muted-foreground">Edit all text and images on your homepage. Changes go live instantly.</p>
            </div>
          </div>
          <Button
            onClick={handleSave}
            disabled={mutation.isPending}
            size="lg"
            className="gap-2"
          >
            {mutation.isPending ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {mutation.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>

        <div className="p-4 bg-primary/5 border border-primary/20 rounded-xl text-sm text-muted-foreground flex items-start gap-3">
          <Info className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
          <span>
            Edit any section below then click <strong>Save Changes</strong>. Your homepage will update immediately — no refresh needed for visitors.
          </span>
        </div>

        <Tabs defaultValue="hero">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="hero" className="gap-2"><User className="w-4 h-4" />Hero</TabsTrigger>
            <TabsTrigger value="about" className="gap-2"><Info className="w-4 h-4" />About</TabsTrigger>
            <TabsTrigger value="skills" className="gap-2"><Zap className="w-4 h-4" />Skills</TabsTrigger>
            <TabsTrigger value="goals" className="gap-2"><Target className="w-4 h-4" />Goals</TabsTrigger>
          </TabsList>

          {/* HERO TAB */}
          <TabsContent value="hero" className="mt-6">
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle>Hero Section</CardTitle>
                <CardDescription>The first thing visitors see — your name, title, and profile.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="space-y-2">
                  <Label>Your Name</Label>
                  <Input
                    value={content.hero.name}
                    onChange={(e) => updateHero("name", e.target.value)}
                    placeholder="e.g. Mojahid Ahammed Siam"
                    className="bg-background"
                  />
                  <p className="text-xs text-muted-foreground">Shown as the big title on the homepage.</p>
                </div>

                <div className="space-y-2">
                  <Label>Tagline / Role</Label>
                  <Input
                    value={content.hero.tagline}
                    onChange={(e) => updateHero("tagline", e.target.value)}
                    placeholder="e.g. Class 9 Business Studies Student"
                    className="bg-background"
                  />
                  <p className="text-xs text-muted-foreground">Small text above your name (role / class).</p>
                </div>

                <div className="space-y-2">
                  <Label>Subtitle</Label>
                  <Input
                    value={content.hero.subtitle}
                    onChange={(e) => updateHero("subtitle", e.target.value)}
                    placeholder="e.g. Student · Technology Enthusiast · Digital Learner"
                    className="bg-background"
                  />
                  <p className="text-xs text-muted-foreground">Short description shown below your name. Use · to separate items.</p>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border/50">
                  <div className="space-y-2">
                    <Label>Profile Image URL</Label>
                    <Input
                      value={content.hero.avatarImageUrl}
                      onChange={(e) => updateHero("avatarImageUrl", e.target.value)}
                      placeholder="https://... (leave empty to use initials)"
                      className="bg-background"
                    />
                    <p className="text-xs text-muted-foreground">Paste a photo URL. Leave empty to show initials instead.</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Initials Text (if no image)</Label>
                    <Input
                      value={content.hero.avatarText}
                      onChange={(e) => updateHero("avatarText", e.target.value)}
                      placeholder="e.g. MAS"
                      maxLength={5}
                      className="bg-background"
                    />
                    <p className="text-xs text-muted-foreground">Shown inside the circle when no image is set.</p>
                  </div>
                </div>

                {/* Live Preview */}
                <div className="mt-4 p-6 rounded-xl bg-muted/40 border border-border/50 space-y-2">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">Preview</p>
                  <p className="text-primary text-sm font-medium uppercase tracking-wider">{content.hero.tagline || "Your tagline"}</p>
                  <h2 className="text-3xl font-bold">
                    Hi, I am{" "}
                    <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary via-cyan-400 to-purple-500">
                      {content.hero.name || "Your Name"}
                    </span>
                  </h2>
                  <p className="text-muted-foreground">{content.hero.subtitle || "Your subtitle"}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ABOUT TAB */}
          <TabsContent value="about" className="mt-6">
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle>About Me Section</CardTitle>
                <CardDescription>A paragraph that tells visitors who you are.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>About Text</Label>
                  <Textarea
                    value={content.about.text}
                    onChange={(e) => updateAbout(e.target.value)}
                    rows={6}
                    placeholder="Write a short description about yourself..."
                    className="bg-background resize-none"
                  />
                  <p className="text-xs text-muted-foreground">{content.about.text.length} characters</p>
                </div>
                <div className="p-5 rounded-xl bg-muted/40 border border-border/50">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">Preview</p>
                  <p className="text-muted-foreground leading-relaxed">{content.about.text || "Your about text will appear here."}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SKILLS TAB */}
          <TabsContent value="skills" className="mt-6">
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle>Skills & Expertise</CardTitle>
                <CardDescription>The skill cards shown on your homepage. Add, edit, or remove skills.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {content.skills.map((skill, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div className="flex-shrink-0 w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                        {index + 1}
                      </div>
                      <Input
                        value={skill.name}
                        onChange={(e) => updateSkill(index, e.target.value)}
                        placeholder="Skill name"
                        className="bg-background"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSkill(index)}
                        className="text-muted-foreground hover:text-destructive flex-shrink-0"
                        disabled={content.skills.length <= 1}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                <Button variant="outline" onClick={addSkill} className="w-full gap-2">
                  <Plus className="w-4 h-4" />
                  Add Skill
                </Button>
                <div className="p-5 rounded-xl bg-muted/40 border border-border/50">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">Preview</p>
                  <div className="flex flex-wrap gap-2">
                    {content.skills.map((s, i) => (
                      <span key={i} className="px-3 py-1.5 bg-primary/10 text-primary rounded-lg text-sm font-medium">{s.name}</span>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* GOALS TAB */}
          <TabsContent value="goals" className="mt-6">
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle>Goals Section</CardTitle>
                <CardDescription>Your personal goals shown on the homepage. Each has a title and short description.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                {content.goals.map((goal, index) => (
                  <div key={index} className="p-4 rounded-xl border border-border/50 bg-background/50 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Goal {index + 1}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeGoal(index)}
                        className="text-muted-foreground hover:text-destructive h-7 px-2"
                        disabled={content.goals.length <= 1}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Goal Title</Label>
                      <Input
                        value={goal.label}
                        onChange={(e) => updateGoal(index, "label", e.target.value)}
                        placeholder="Goal title"
                        className="bg-background h-9"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Description</Label>
                      <Input
                        value={goal.desc}
                        onChange={(e) => updateGoal(index, "desc", e.target.value)}
                        placeholder="Short description"
                        className="bg-background h-9"
                      />
                    </div>
                  </div>
                ))}
                <Button variant="outline" onClick={addGoal} className="w-full gap-2">
                  <Plus className="w-4 h-4" />
                  Add Goal
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button Bottom */}
        <div className="flex justify-end pt-4 border-t border-border/50">
          <Button
            onClick={handleSave}
            disabled={mutation.isPending}
            size="lg"
            className="gap-2 min-w-[160px]"
          >
            {mutation.isPending ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {mutation.isPending ? "Saving..." : "Save All Changes"}
          </Button>
        </div>
      </div>
    </AdminLayout>
  );
}
