import { useEffect } from "react";
import { motion } from "framer-motion";
import { useListGalleryPhotos } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { ImageIcon } from "lucide-react";

export default function Gallery() {
  useEffect(() => {
    document.title = "Gallery | Mojahid Ahammed Siam";
  }, []);

  const { data: photos, isLoading } = useListGalleryPhotos();

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div 
        className="mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Gallery</h1>
        <p className="text-xl text-muted-foreground max-w-2xl">Moments, events, and visual memories from my journey.</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {isLoading ? (
          Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="aspect-square w-full rounded-xl" />)
        ) : photos?.length ? (
          photos.map((photo, i) => (
            <motion.div
              key={photo.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className="group relative aspect-square rounded-xl overflow-hidden bg-muted"
            >
              <img 
                src={photo.imageUrl} 
                alt={photo.altText || photo.caption || "Gallery photo"} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              {photo.caption && (
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <p className="text-white text-sm font-medium">{photo.caption}</p>
                </div>
              )}
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-32 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
              <ImageIcon className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-2">Gallery empty</h3>
            <p className="text-muted-foreground">Check back later for new photos.</p>
          </div>
        )}
      </div>
    </div>
  );
}