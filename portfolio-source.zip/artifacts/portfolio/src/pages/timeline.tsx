import { useEffect } from "react";
import { motion } from "framer-motion";
import { useListTimelineItems } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { format } from "date-fns";
import { Trophy, Star, BookOpen, Rocket, Compass } from "lucide-react";

export default function Timeline() {
  useEffect(() => {
    document.title = "Timeline | Mojahid Ahammed Siam";
  }, []);

  const { data: items, isLoading } = useListTimelineItems();

  const getIcon = (type: string) => {
    switch(type) {
      case 'achievement': return <Trophy className="w-5 h-5 text-yellow-500" />;
      case 'certification': return <BookOpen className="w-5 h-5 text-blue-500" />;
      case 'project': return <Rocket className="w-5 h-5 text-purple-500" />;
      case 'milestone': return <Star className="w-5 h-5 text-cyan-500" />;
      default: return <Compass className="w-5 h-5 text-primary" />;
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <motion.div 
        className="mb-16 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">My Journey</h1>
        <p className="text-xl text-muted-foreground">A timeline of my learning, achievements, and milestones.</p>
      </motion.div>

      <div className="relative">
        {/* Timeline track */}
        <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-border -translate-x-1/2 hidden md:block" />

        <div className="space-y-12">
          {isLoading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex flex-col md:flex-row gap-8 w-full">
                <Skeleton className="h-32 w-full rounded-xl" />
              </div>
            ))
          ) : items?.length ? (
            items.map((item, i) => {
              const isEven = i % 2 === 0;
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className={`flex flex-col md:flex-row gap-8 items-center w-full ${isEven ? 'md:flex-row-reverse' : ''}`}
                >
                  <div className={`flex-1 w-full md:w-1/2 ${isEven ? 'md:text-left' : 'md:text-right'}`}>
                    <Card className="hover-elevate transition-all border-border/50 group">
                      <CardContent className="p-6">
                        <div className={`flex items-center gap-3 mb-3 ${isEven ? 'justify-start' : 'md:justify-end justify-start'}`}>
                          <span className="text-sm font-bold text-primary px-3 py-1 rounded-full bg-primary/10">
                            {format(new Date(item.date), "MMM yyyy")}
                          </span>
                          <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                            {item.type}
                          </span>
                        </div>
                        <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{item.title}</h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {/* Timeline marker */}
                  <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 w-12 h-12 rounded-full border-4 border-background bg-card shadow-lg items-center justify-center z-10">
                    {getIcon(item.type)}
                  </div>
                  
                  {/* Empty spacer for grid alignment */}
                  <div className="hidden md:block flex-1 w-1/2" />
                </motion.div>
              );
            })
          ) : (
            <div className="py-20 text-center text-muted-foreground">
              Timeline is currently empty.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}