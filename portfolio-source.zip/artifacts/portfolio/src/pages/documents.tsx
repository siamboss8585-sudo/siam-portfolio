import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useListDocuments } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, FileText, Download, FileJson, FileImage, FileCode, FileType } from "lucide-react";
import { format } from "date-fns";

export default function Documents() {
  useEffect(() => {
    document.title = "Documents | Mojahid Ahammed Siam";
  }, []);

  const [search, setSearch] = useState("");
  const { data: documents, isLoading } = useListDocuments({ search: search || undefined });

  const getFileIcon = (type: string) => {
    if (type.includes("pdf")) return <FileText className="w-8 h-8 text-red-500" />;
    if (type.includes("json")) return <FileJson className="w-8 h-8 text-yellow-500" />;
    if (type.includes("image")) return <FileImage className="w-8 h-8 text-green-500" />;
    if (type.includes("javascript") || type.includes("typescript")) return <FileCode className="w-8 h-8 text-blue-500" />;
    return <FileType className="w-8 h-8 text-gray-500" />;
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-5xl">
      <motion.div 
        className="mb-12 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Document Library</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">Resources, notes, and study materials I've collected or created.</p>
      </motion.div>

      <div className="max-w-md mx-auto mb-12">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input 
            placeholder="Search documents..." 
            className="pl-10"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {isLoading ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32 w-full rounded-xl" />)
        ) : documents?.length ? (
          documents.map((doc, i) => (
            <motion.div
              key={doc.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="hover-elevate transition-colors hover:border-primary/50 group">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-muted group-hover:bg-primary/10 transition-colors">
                    {getFileIcon(doc.fileType)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <h3 className="font-semibold text-lg truncate group-hover:text-primary transition-colors">
                        {doc.title}
                      </h3>
                      <Badge variant="outline" className="shrink-0">{doc.category}</Badge>
                    </div>
                    {doc.description && (
                      <p className="text-sm text-muted-foreground line-clamp-1 mb-4">{doc.description}</p>
                    )}
                    <div className="flex items-center justify-between mt-auto">
                      <div className="text-xs text-muted-foreground flex gap-3">
                        <span>{format(new Date(doc.createdAt), "MMM d, yyyy")}</span>
                        {doc.fileSize && <span>• {doc.fileSize}</span>}
                      </div>
                      <Button size="sm" variant="ghost" className="rounded-full w-8 h-8 p-0 hover:bg-primary hover:text-primary-foreground" asChild>
                        <a href={doc.fileUrl} target="_blank" rel="noopener noreferrer" download>
                          <Download className="w-4 h-4" />
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-20 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
              <FileText className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-2">No documents found</h3>
            <p className="text-muted-foreground">No resources match your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}