import { useEffect, useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { useGetSiteStats } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Code, Terminal, MonitorPlay, Shield, Briefcase, Users, Layout as LayoutIcon, PenTool, Star } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const ICON_MAP: Record<string, React.ElementType> = {
  "Programming": Code,
  "Coding": Terminal,
  "Cybersecurity": Shield,
  "Video Editing": MonitorPlay,
  "Digital Tools": LayoutIcon,
  "Content Creation": PenTool,
  "Business Studies": Briefcase,
  "Communication": Users,
};

interface HomeContent {
  hero: {
    name: string;
    tagline: string;
    subtitle: string;
    avatarText: string;
    avatarImageUrl: string;
  };
  about: {
    text: string;
  };
  skills: { name: string }[];
  goals: { label: string; desc: string }[];
}

const DEFAULT_CONTENT: HomeContent = {
  hero: {
    name: "Mojahid Ahammed Siam",
    tagline: "Class 9 Business Studies Student",
    subtitle: "Student · Technology Enthusiast · Digital Learner",
    avatarText: "MAS",
    avatarImageUrl: "",
  },
  about: {
    text: "Hello! I am Mojahid Ahammed Siam, a Class 9 Business Studies student passionate about technology, digital skills, and continuous learning.",
  },
  skills: [
    { name: "Programming" },
    { name: "Coding" },
    { name: "Cybersecurity" },
    { name: "Video Editing" },
    { name: "Digital Tools" },
    { name: "Content Creation" },
    { name: "Business Studies" },
    { name: "Communication" },
  ],
  goals: [
    { label: "Financial Independence", desc: "Building skills to create my own income." },
    { label: "Strong Personal Brand", desc: "Becoming recognizable in technology & digital skills." },
    { label: "Technology Expertise", desc: "Deep knowledge across cybersecurity, coding, and tools." },
    { label: "Continuous Learning", desc: "Never stopping — always growing, always improving." },
    { label: "Meaningful Projects", desc: "Creating things that matter and help others." },
  ],
};

const DEFAULT_SECTIONS: Record<string, boolean> = {
  "Hero": true,
  "About Me": true,
  "Skills": true,
  "Goals": true,
  "Latest Posts": true,
  "Featured Projects": true,
  "Contact CTA": true,
};

export default function Home() {
  const [sections, setSections] = useState<Record<string, boolean>>(DEFAULT_SECTIONS);

  const { data: rawContent } = useQuery({
    queryKey: ["site-content"],
    queryFn: async () => {
      const res = await fetch("/api/content");
      if (!res.ok) return {};
      return res.json() as Promise<Record<string, string>>;
    },
    staleTime: 60_000,
  });

  const content: HomeContent = (() => {
    if (!rawContent?.home_content) return DEFAULT_CONTENT;
    try {
      return { ...DEFAULT_CONTENT, ...JSON.parse(rawContent.home_content) };
    } catch {
      return DEFAULT_CONTENT;
    }
  })();

  useEffect(() => {
    document.title = "Mojahid Ahammed Siam | Digital HQ";
    const saved = localStorage.getItem("visible_sections");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSections({ ...DEFAULT_SECTIONS, ...parsed });
      } catch {
        setSections(DEFAULT_SECTIONS);
      }
    }
  }, []);

  const { data: stats, isLoading } = useGetSiteStats();

  return (
    <div className="flex flex-col w-full">
      {/* Hero */}
      {sections["Hero"] !== false && (
        <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden py-20">
          <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />
          <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-12">
            <motion.div
              className="flex-1 space-y-8 text-center md:text-left"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <motion.p
                className="text-primary font-medium tracking-wider uppercase text-sm"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}
              >
                {content.hero.tagline}
              </motion.p>
              <motion.h1
                className="text-5xl md:text-7xl font-bold tracking-tighter"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
              >
                Hi, I am <br />
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary via-cyan-400 to-purple-500">
                  {content.hero.name}
                </span>
              </motion.h1>
              <motion.p
                className="text-xl text-muted-foreground max-w-2xl mx-auto md:mx-0"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}
              >
                {content.hero.subtitle}
              </motion.p>
              <motion.div
                className="flex flex-wrap items-center justify-center md:justify-start gap-4"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
              >
                <Link href="/projects"><Button size="lg" className="h-12 px-8">Explore Projects</Button></Link>
                <Link href="/blog"><Button size="lg" variant="outline" className="h-12 px-8">Read Blog</Button></Link>
                <Link href="/contact"><Button size="lg" variant="ghost" className="h-12 px-8">Contact Me</Button></Link>
              </motion.div>
            </motion.div>

            <motion.div
              className="flex-1 flex justify-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, type: "spring" }}
            >
              <motion.div
                className="relative w-64 h-64 md:w-80 md:h-80 rounded-full bg-gradient-to-br from-primary via-cyan-400 to-purple-500 p-1 shadow-2xl shadow-primary/20"
                animate={{ y: [0, -12, 0] }}
                transition={{ repeat: Infinity, duration: 3.5, ease: "easeInOut" }}
              >
                <div className="absolute inset-0 rounded-full bg-background/50 backdrop-blur-sm flex items-center justify-center overflow-hidden">
                  {content.hero.avatarImageUrl ? (
                    <img src={content.hero.avatarImageUrl} alt={content.hero.name} className="w-full h-full object-cover rounded-full" />
                  ) : (
                    <span className="text-6xl md:text-8xl font-bold text-white/90">{content.hero.avatarText}</span>
                  )}
                </div>
              </motion.div>
            </motion.div>
          </div>
        </section>
      )}

      {/* About */}
      {sections["About Me"] !== false && (
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4 text-center max-w-3xl">
            <motion.h2
              className="text-3xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            >
              About Me
            </motion.h2>
            <motion.p
              className="text-lg leading-relaxed text-muted-foreground"
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}
            >
              {content.about.text}
            </motion.p>
          </div>
        </section>
      )}

      {/* Skills */}
      {sections["Skills"] !== false && (
        <section className="py-24">
          <div className="container mx-auto px-4">
            <motion.div
              className="text-center mb-16"
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold">Skills & Expertise</h2>
              <p className="mt-4 text-muted-foreground">What I'm building my foundation on</p>
            </motion.div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {content.skills.map((skill, index) => {
                const Icon = ICON_MAP[skill.name] ?? Star;
                return (
                  <motion.div
                    key={skill.name + index}
                    initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }} transition={{ delay: index * 0.07 }}
                  >
                    <Card className="transition-all duration-300 border-border/50 bg-card/50 backdrop-blur-sm group hover:border-primary/40 hover:-translate-y-1 hover:shadow-lg">
                      <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
                        <div className="p-3 rounded-2xl bg-primary/10 text-primary group-hover:scale-110 transition-transform duration-300">
                          <Icon className="w-8 h-8" />
                        </div>
                        <h3 className="font-semibold">{skill.name}</h3>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Goals */}
      {sections["Goals"] !== false && (
        <section className="py-20 bg-muted/20 border-y border-border/40">
          <div className="container mx-auto px-4">
            <motion.div
              className="text-center mb-14"
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold">Goals</h2>
              <p className="mt-4 text-muted-foreground">What I'm working towards every day</p>
            </motion.div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
              {content.goals.map((goal, index) => (
                <motion.div
                  key={goal.label + index}
                  initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }} transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full border-border/50 bg-card/60 hover:border-primary/40 transition-colors">
                    <CardContent className="p-6 space-y-2">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />
                        <h3 className="font-bold">{goal.label}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground pl-5">{goal.desc}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured Projects */}
      {sections["Featured Projects"] !== false && (
        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-3xl font-bold">Featured Projects</h2>
              <Link href="/projects" className="flex items-center gap-2 text-primary hover:underline text-sm font-medium">
                View all <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {isLoading ? (
                Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-64 w-full rounded-xl" />)
              ) : stats?.recentProjects?.length ? (
                stats.recentProjects.slice(0, 3).map((project) => (
                  <Card key={project.id} className="overflow-hidden flex flex-col hover:-translate-y-1 hover:shadow-xl transition-all duration-300 border-border/50">
                    <div className="h-44 bg-muted">
                      {project.imageUrl ? (
                        <img src={project.imageUrl} alt={project.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-primary/20">
                          <Code className="w-12 h-12" />
                        </div>
                      )}
                    </div>
                    <CardContent className="p-6 flex-1 flex flex-col">
                      <h3 className="text-lg font-bold mb-2">{project.title}</h3>
                      <p className="text-muted-foreground text-sm line-clamp-2 mb-4">{project.description}</p>
                      <div className="mt-auto flex flex-wrap gap-2">
                        {project.technologies.slice(0, 3).map((tech) => (
                          <Badge key={tech} variant="secondary" className="text-xs">{tech}</Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-full text-center py-12 text-muted-foreground">No projects added yet.</div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Latest Posts */}
      {sections["Latest Posts"] !== false && (
        <section className="py-24 bg-muted/20 border-t border-border/40">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-3xl font-bold">Latest Writing</h2>
              <Link href="/blog" className="flex items-center gap-2 text-primary hover:underline text-sm font-medium">
                Read more <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {isLoading ? (
                Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-48 w-full rounded-xl" />)
              ) : stats?.recentPosts?.length ? (
                stats.recentPosts.slice(0, 3).map((post) => (
                  <Link key={post.id} href={`/blog/${post.id}`}>
                    <Card className="h-full hover:-translate-y-1 hover:shadow-lg transition-all duration-300 cursor-pointer border-border/50 hover:border-primary/40">
                      <CardContent className="p-6 flex flex-col h-full">
                        <Badge className="w-fit mb-4">{post.category}</Badge>
                        <h3 className="text-lg font-bold mb-2 line-clamp-2">{post.title}</h3>
                        <p className="text-muted-foreground text-sm line-clamp-2 mt-auto">{post.excerpt}</p>
                      </CardContent>
                    </Card>
                  </Link>
                ))
              ) : (
                <div className="col-span-full text-center py-12 text-muted-foreground">No posts published yet.</div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      {sections["Contact CTA"] !== false && (
        <section className="py-32 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-background to-primary/5" />
          <div className="container mx-auto px-4 text-center relative z-10">
            <motion.h2
              className="text-4xl md:text-5xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            >
              Let's build something.
            </motion.h2>
            <motion.p
              className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}
            >
              Whether it's a project, a learning opportunity, or just a conversation about technology.
            </motion.p>
            <Link href="/contact">
              <Button size="lg" className="h-14 px-10 text-lg rounded-full shadow-xl shadow-primary/20 hover:scale-105 transition-transform">
                Get in Touch
              </Button>
            </Link>
          </div>
        </section>
      )}
    </div>
  );
}
