import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useListProjects } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Github, ExternalLink, Code } from "lucide-react";

export default function Projects() {
  useEffect(() => {
    document.title = "Projects | Mojahid Ahammed Siam";
  }, []);

  const [search, setSearch] = useState("");
  const { data: projects, isLoading } = useListProjects({ search: search || undefined });

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div 
        className="mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Projects</h1>
        <p className="text-xl text-muted-foreground max-w-2xl">Things I've built, exploring technology and solving problems.</p>
      </motion.div>

      <div className="max-w-md mb-12">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input 
            placeholder="Search projects..." 
            className="pl-10"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-[400px] w-full rounded-xl" />)
        ) : projects?.length ? (
          projects.map((project, i) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="h-full hover-elevate overflow-hidden border-border/50 transition-colors flex flex-col group">
                <div className="h-56 bg-muted relative overflow-hidden">
                  {project.imageUrl ? (
                    <img 
                      src={project.imageUrl} 
                      alt={project.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-primary/5 text-primary">
                      <Code className="w-16 h-16 opacity-20" />
                    </div>
                  )}
                  {project.featured && (
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-purple text-white hover:bg-purple/90 border-none shadow-lg">Featured</Badge>
                    </div>
                  )}
                </div>
                <CardContent className="p-6 flex flex-col flex-1">
                  <h2 className="text-2xl font-bold mb-3 group-hover:text-primary transition-colors">{project.title}</h2>
                  <p className="text-muted-foreground text-sm line-clamp-3 mb-6 flex-1">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.technologies.map(tech => (
                      <Badge key={tech} variant="secondary" className="text-xs">{tech}</Badge>
                    ))}
                  </div>

                  <div className="flex items-center gap-3 mt-auto">
                    {project.demoUrl && (
                      <Button variant="default" size="sm" className="flex-1" asChild>
                        <a href={project.demoUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-2" /> Live Demo
                        </a>
                      </Button>
                    )}
                    {project.githubUrl && (
                      <Button variant="outline" size="sm" className="flex-1" asChild>
                        <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                          <Github className="w-4 h-4 mr-2" /> Code
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-20 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
              <Code className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-2">No projects found</h3>
            <p className="text-muted-foreground">Try adjusting your search criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
}