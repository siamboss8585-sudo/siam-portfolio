import { Switch, Route, Router as WouterRouter, useLocation, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";

import Home from "@/pages/home";
import Blog from "@/pages/blog";
import BlogDetail from "@/pages/blog-detail";
import Projects from "@/pages/projects";
import Documents from "@/pages/documents";
import Gallery from "@/pages/gallery";
import Timeline from "@/pages/timeline";
import Contact from "@/pages/contact";
import NotFound from "@/pages/not-found";

import AdminLogin from "@/pages/admin/login";
import AdminDashboard from "@/pages/admin/index";
import AdminContent from "@/pages/admin/content";
import AdminBlog from "@/pages/admin/blog";
import AdminProjects from "@/pages/admin/projects";
import AdminGallery from "@/pages/admin/gallery";
import AdminDocuments from "@/pages/admin/documents";
import AdminTimeline from "@/pages/admin/timeline";
import AdminMessages from "@/pages/admin/messages";
import AdminSections from "@/pages/admin/sections";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: 1,
    },
  },
});

function AdminGuard({ children }: { children: React.ReactNode }) {
  const isAuth =
    typeof window !== "undefined" && localStorage.getItem("admin_auth") === "true";
  if (!isAuth) return <Redirect to="/admin/login" />;
  return <>{children}</>;
}

function PublicRoutes() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/blog" component={Blog} />
        <Route path="/blog/:id" component={BlogDetail} />
        <Route path="/projects" component={Projects} />
        <Route path="/documents" component={Documents} />
        <Route path="/gallery" component={Gallery} />
        <Route path="/timeline" component={Timeline} />
        <Route path="/contact" component={Contact} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function AdminRoutes() {
  return (
    <Switch>
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin">
        <AdminGuard><AdminDashboard /></AdminGuard>
      </Route>
      <Route path="/admin/content">
        <AdminGuard><AdminContent /></AdminGuard>
      </Route>
      <Route path="/admin/blog">
        <AdminGuard><AdminBlog /></AdminGuard>
      </Route>
      <Route path="/admin/projects">
        <AdminGuard><AdminProjects /></AdminGuard>
      </Route>
      <Route path="/admin/gallery">
        <AdminGuard><AdminGallery /></AdminGuard>
      </Route>
      <Route path="/admin/documents">
        <AdminGuard><AdminDocuments /></AdminGuard>
      </Route>
      <Route path="/admin/timeline">
        <AdminGuard><AdminTimeline /></AdminGuard>
      </Route>
      <Route path="/admin/messages">
        <AdminGuard><AdminMessages /></AdminGuard>
      </Route>
      <Route path="/admin/sections">
        <AdminGuard><AdminSections /></AdminGuard>
      </Route>
    </Switch>
  );
}

function AppRouter() {
  const [location] = useLocation();
  return location.startsWith("/admin") ? <AdminRoutes /> : <PublicRoutes />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AppRouter />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
