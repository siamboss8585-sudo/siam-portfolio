import { Link } from "wouter";
import { ThemeProvider } from "./theme-provider";
import { Navbar } from "./navbar";
import { Footer } from "./footer";

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="siam-theme">
      <div className="min-h-screen flex flex-col bg-background text-foreground selection:bg-primary selection:text-white">
        <Navbar />
        <main className="flex-1 w-full pt-16">
          {children}
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  );
}