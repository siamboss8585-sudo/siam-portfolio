import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="border-t border-border/40 bg-background/95 mt-auto">
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-3">
            <h3 className="font-bold text-lg">Mojahid Ahammed Siam</h3>
            <p className="text-muted-foreground text-sm italic">
              "Stay curious, keep learning, and improve every day."
            </p>
          </div>
          
          <div className="space-y-3">
            <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Links</h4>
            <nav className="flex flex-col space-y-2 text-sm">
              <Link href="/blog" className="hover:text-primary transition-colors">Blog</Link>
              <Link href="/projects" className="hover:text-primary transition-colors">Projects</Link>
              <Link href="/timeline" className="hover:text-primary transition-colors">Timeline</Link>
              <Link href="/contact" className="hover:text-primary transition-colors">Contact</Link>
            </nav>
          </div>
          
          <div className="space-y-3">
            <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Connect</h4>
            <nav className="flex flex-col space-y-2 text-sm">
              <a href="#" className="hover:text-primary transition-colors">GitHub</a>
              <a href="#" className="hover:text-primary transition-colors">LinkedIn</a>
              <a href="#" className="hover:text-primary transition-colors">Twitter</a>
            </nav>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-border/40 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Mojahid Ahammed Siam. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}