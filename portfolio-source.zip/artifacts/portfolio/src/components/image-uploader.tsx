import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRequestUploadUrl } from "@workspace/api-client-react";
import { UploadCloud, Link as LinkIcon, Loader2, Image as ImageIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ImageUploaderProps {
  imageUrl?: string;
  onUploadComplete: (url: string) => void;
  label?: string;
}

export function ImageUploader({ imageUrl, onUploadComplete, label = "Cover Image" }: ImageUploaderProps) {
  const [mode, setMode] = useState<"upload" | "url">("upload");
  const [urlInput, setUrlInput] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const requestUploadUrl = useRequestUploadUrl();
  const { toast } = useToast();

  const handleUrlSubmit = () => {
    if (urlInput.trim()) {
      onUploadComplete(urlInput.trim());
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      
      const response = await requestUploadUrl.mutateAsync({
        data: {
          name: file.name,
          size: file.size,
          contentType: file.type
        }
      });

      const { uploadURL, objectPath } = response;

      await fetch(uploadURL, {
        method: "PUT",
        body: file,
        headers: {
          "Content-Type": file.type
        }
      });

      const finalUrl = `/api/storage${objectPath}`;
      onUploadComplete(finalUrl);
      
      toast({
        title: "Upload successful",
        description: "Image has been uploaded successfully.",
      });
    } catch (error) {
      console.error("Upload error:", error);
      toast({
        title: "Upload failed",
        description: "There was an error uploading your image.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  return (
    <div className="space-y-4 border rounded-md p-4 bg-muted/20">
      <Label>{label}</Label>
      
      {imageUrl && (
        <div className="relative aspect-video w-full max-w-sm overflow-hidden rounded-md border bg-muted flex items-center justify-center">
          {imageUrl.endsWith(".pdf") || imageUrl.endsWith(".doc") || imageUrl.endsWith(".docx") ? (
             <div className="flex flex-col items-center gap-2 text-muted-foreground p-4 text-center break-all">
                <ImageIcon className="w-8 h-8 opacity-50" />
                <span className="text-xs">{imageUrl}</span>
             </div>
          ) : (
            <img 
              src={imageUrl} 
              alt="Preview" 
              className="object-contain w-full h-full"
            />
          )}
        </div>
      )}

      <div className="flex items-center gap-2 mb-4">
        <Button 
          type="button" 
          variant={mode === "upload" ? "secondary" : "ghost"} 
          size="sm"
          onClick={() => setMode("upload")}
        >
          <UploadCloud className="w-4 h-4 mr-2" /> Upload File
        </Button>
        <Button 
          type="button" 
          variant={mode === "url" ? "secondary" : "ghost"} 
          size="sm"
          onClick={() => setMode("url")}
        >
          <LinkIcon className="w-4 h-4 mr-2" /> Paste URL
        </Button>
      </div>

      {mode === "upload" ? (
        <div className="space-y-2">
          <Input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            ref={fileInputRef}
            onChange={handleFileChange}
            disabled={isUploading}
          />
          <Button 
            type="button" 
            variant="outline" 
            className="w-full h-24 border-dashed"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
          >
            {isUploading ? (
              <span className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="w-5 h-5 animate-spin" /> Uploading...
              </span>
            ) : (
              <span className="flex flex-col items-center gap-2 text-muted-foreground">
                <UploadCloud className="w-6 h-6" /> Click to select an image
              </span>
            )}
          </Button>
        </div>
      ) : (
        <div className="flex gap-2">
          <Input 
            placeholder="https://example.com/image.jpg" 
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
          />
          <Button type="button" onClick={handleUrlSubmit}>Apply URL</Button>
        </div>
      )}
    </div>
  );
}