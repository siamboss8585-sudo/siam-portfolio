import { Router } from "express";
import { db, contactMessagesTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { SubmitContactFormBody } from "@workspace/api-zod";

const router = Router();

router.post("/", async (req, res) => {
  try {
    const body = SubmitContactFormBody.parse(req.body);
    const [msg] = await db.insert(contactMessagesTable).values(body).returning();
    res.status(201).json({ ...msg, createdAt: msg.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to submit contact message" });
  }
});

router.get("/messages", async (req, res) => {
  try {
    const messages = await db.select().from(contactMessagesTable).orderBy(desc(contactMessagesTable.createdAt));
    res.json(messages.map((m) => ({ ...m, createdAt: m.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list contact messages" });
  }
});

export default router;
