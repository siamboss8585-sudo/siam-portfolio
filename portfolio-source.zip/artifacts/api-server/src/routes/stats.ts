import { Router } from "express";
import { db, blogPostsTable, projectsTable, documentsTable, galleryPhotosTable, timelineItemsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { sql } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const [blogCount] = await db.select({ count: sql<number>`count(*)::int` }).from(blogPostsTable);
    const [projectCount] = await db.select({ count: sql<number>`count(*)::int` }).from(projectsTable);
    const [docCount] = await db.select({ count: sql<number>`count(*)::int` }).from(documentsTable);
    const [photoCount] = await db.select({ count: sql<number>`count(*)::int` }).from(galleryPhotosTable);
    const [timelineCount] = await db.select({ count: sql<number>`count(*)::int` }).from(timelineItemsTable);
    const [featuredCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(blogPostsTable)
      .where(eq(blogPostsTable.featured, true));

    const recentPosts = await db
      .select()
      .from(blogPostsTable)
      .orderBy(desc(blogPostsTable.createdAt))
      .limit(3);

    const recentProjects = await db
      .select()
      .from(projectsTable)
      .orderBy(desc(projectsTable.createdAt))
      .limit(3);

    res.json({
      totalBlogPosts: blogCount?.count ?? 0,
      totalProjects: projectCount?.count ?? 0,
      totalDocuments: docCount?.count ?? 0,
      totalGalleryPhotos: photoCount?.count ?? 0,
      totalTimelineItems: timelineCount?.count ?? 0,
      featuredBlogPosts: featuredCount?.count ?? 0,
      recentPosts: recentPosts.map((p) => ({
        ...p,
        tags: p.tags ?? [],
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt?.toISOString() ?? null,
      })),
      recentProjects: recentProjects.map((p) => ({
        ...p,
        technologies: p.technologies ?? [],
        createdAt: p.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get stats" });
  }
});

export default router;
