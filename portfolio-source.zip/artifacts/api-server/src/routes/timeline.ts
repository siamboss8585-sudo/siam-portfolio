import { Router } from "express";
import { db, timelineItemsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  CreateTimelineItemBody,
  DeleteTimelineItemParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const items = await db.select().from(timelineItemsTable).orderBy(desc(timelineItemsTable.createdAt));
    res.json(items.map((i) => ({ ...i, createdAt: i.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list timeline items" });
  }
});

router.post("/", async (req, res) => {
  try {
    const body = CreateTimelineItemBody.parse(req.body);
    const [item] = await db.insert(timelineItemsTable).values(body).returning();
    res.status(201).json({ ...item, createdAt: item.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create timeline item" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const { id } = DeleteTimelineItemParams.parse({ id: Number(req.params.id) });
    await db.delete(timelineItemsTable).where(eq(timelineItemsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete timeline item" });
  }
});

export default router;
