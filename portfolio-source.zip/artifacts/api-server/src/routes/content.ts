import { Router } from "express";
import { db } from "@workspace/db";
import { pageContentTable } from "@workspace/db";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const rows = await db.select().from(pageContentTable);
    const result: Record<string, string> = {};
    for (const row of rows) {
      result[row.key] = row.value;
    }
    res.json(result);
  } catch (err) {
    req.log.error(err, "Failed to get content");
    res.status(500).json({ error: "Failed to get content" });
  }
});

router.put("/:key", async (req, res) => {
  try {
    const { key } = req.params;
    const { value } = req.body as { value: string };
    if (typeof value !== "string") {
      res.status(400).json({ error: "value must be a string" });
      return;
    }
    await db
      .insert(pageContentTable)
      .values({ key, value })
      .onConflictDoUpdate({
        target: pageContentTable.key,
        set: { value, updatedAt: new Date() },
      });
    res.json({ success: true });
  } catch (err) {
    req.log.error(err, "Failed to update content");
    res.status(500).json({ error: "Failed to update content" });
  }
});

export default router;
