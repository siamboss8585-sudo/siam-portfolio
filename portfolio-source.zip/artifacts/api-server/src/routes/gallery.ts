import { Router } from "express";
import { db, galleryPhotosTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  CreateGalleryPhotoBody,
  DeleteGalleryPhotoParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const photos = await db.select().from(galleryPhotosTable).orderBy(desc(galleryPhotosTable.createdAt));
    res.json(photos.map((p) => ({ ...p, createdAt: p.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list gallery photos" });
  }
});

router.post("/", async (req, res) => {
  try {
    const body = CreateGalleryPhotoBody.parse(req.body);
    const [photo] = await db.insert(galleryPhotosTable).values(body).returning();
    res.status(201).json({ ...photo, createdAt: photo.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to add gallery photo" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const { id } = DeleteGalleryPhotoParams.parse({ id: Number(req.params.id) });
    await db.delete(galleryPhotosTable).where(eq(galleryPhotosTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete gallery photo" });
  }
});

export default router;
