import { Router } from "express";
import { db, documentsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  ListDocumentsQueryParams,
  CreateDocumentBody,
  DeleteDocumentParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const query = ListDocumentsQueryParams.parse(req.query);
    let docs = await db.select().from(documentsTable).orderBy(desc(documentsTable.createdAt));

    if (query.search) {
      const s = query.search.toLowerCase();
      docs = docs.filter(
        (d) => d.title.toLowerCase().includes(s) || (d.description ?? "").toLowerCase().includes(s)
      );
    }
    if (query.category) {
      docs = docs.filter((d) => d.category === query.category);
    }

    res.json(docs.map((d) => ({ ...d, createdAt: d.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list documents" });
  }
});

router.post("/", async (req, res) => {
  try {
    const body = CreateDocumentBody.parse(req.body);
    const [doc] = await db.insert(documentsTable).values(body).returning();
    res.status(201).json({ ...doc, createdAt: doc.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create document" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const { id } = DeleteDocumentParams.parse({ id: Number(req.params.id) });
    await db.delete(documentsTable).where(eq(documentsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete document" });
  }
});

export default router;
