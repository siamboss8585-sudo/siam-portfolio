import { Router, type IRouter } from "express";
import healthRouter from "./health";
import blogRouter from "./blog";
import projectsRouter from "./projects";
import documentsRouter from "./documents";
import galleryRouter from "./gallery";
import timelineRouter from "./timeline";
import contactRouter from "./contact";
import statsRouter from "./stats";
import storageRouter from "./storage";
import contentRouter from "./content";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/blog/categories", blogRouter);
router.use("/blog", blogRouter);
router.use("/projects", projectsRouter);
router.use("/documents", documentsRouter);
router.use("/gallery", galleryRouter);
router.use("/timeline", timelineRouter);
router.use("/contact", contactRouter);
router.use("/stats", statsRouter);
router.use("/content", contentRouter);
router.use(storageRouter);

export default router;
