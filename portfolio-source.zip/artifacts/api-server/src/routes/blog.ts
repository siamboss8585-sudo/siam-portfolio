import { Router } from "express";
import { db, blogPostsTable } from "@workspace/db";
import { eq, ilike, or, sql, desc } from "drizzle-orm";
import {
  ListBlogPostsQueryParams,
  CreateBlogPostBody,
  UpdateBlogPostParams,
  UpdateBlogPostBody,
  DeleteBlogPostParams,
  GetBlogPostParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const query = ListBlogPostsQueryParams.parse(req.query);
    let conditions: ReturnType<typeof eq>[] = [];

    let dbQuery = db.select().from(blogPostsTable);

    const posts = await db.select().from(blogPostsTable).orderBy(desc(blogPostsTable.createdAt));

    let filtered = posts;
    if (query.search) {
      const s = query.search.toLowerCase();
      filtered = filtered.filter(
        (p) => p.title.toLowerCase().includes(s) || (p.excerpt ?? "").toLowerCase().includes(s)
      );
    }
    if (query.category) {
      filtered = filtered.filter((p) => p.category === query.category);
    }
    if (query.tag) {
      filtered = filtered.filter((p) => p.tags.includes(query.tag!));
    }
    if (query.featured !== undefined) {
      filtered = filtered.filter((p) => p.featured === query.featured);
    }

    res.json(
      filtered.map((p) => ({
        ...p,
        tags: p.tags ?? [],
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt?.toISOString() ?? null,
      }))
    );
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list blog posts" });
  }
});

router.get("/categories", async (req, res) => {
  try {
    const posts = await db.select({ category: blogPostsTable.category }).from(blogPostsTable);
    const counts: Record<string, number> = {};
    for (const p of posts) {
      counts[p.category] = (counts[p.category] ?? 0) + 1;
    }
    res.json(Object.entries(counts).map(([category, count]) => ({ category, count })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get categories" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const { id } = GetBlogPostParams.parse({ id: Number(req.params.id) });
    const [post] = await db.select().from(blogPostsTable).where(eq(blogPostsTable.id, id));
    if (!post) return res.status(404).json({ error: "Not found" });
    res.json({
      ...post,
      tags: post.tags ?? [],
      createdAt: post.createdAt.toISOString(),
      updatedAt: post.updatedAt?.toISOString() ?? null,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get blog post" });
  }
});

router.post("/", async (req, res) => {
  try {
    const body = CreateBlogPostBody.parse(req.body);
    const wordCount = body.content.split(/\s+/).length;
    const readingTime = Math.max(1, Math.ceil(wordCount / 200));
    const slug = body.slug ?? body.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const [post] = await db
      .insert(blogPostsTable)
      .values({
        ...body,
        slug,
        tags: body.tags ?? [],
        featured: body.featured ?? false,
        readingTime,
      })
      .returning();
    res.status(201).json({
      ...post,
      tags: post.tags ?? [],
      createdAt: post.createdAt.toISOString(),
      updatedAt: post.updatedAt?.toISOString() ?? null,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create blog post" });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const { id } = UpdateBlogPostParams.parse({ id: Number(req.params.id) });
    const body = UpdateBlogPostBody.parse(req.body);
    const [post] = await db
      .update(blogPostsTable)
      .set(body)
      .where(eq(blogPostsTable.id, id))
      .returning();
    if (!post) return res.status(404).json({ error: "Not found" });
    res.json({
      ...post,
      tags: post.tags ?? [],
      createdAt: post.createdAt.toISOString(),
      updatedAt: post.updatedAt?.toISOString() ?? null,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update blog post" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const { id } = DeleteBlogPostParams.parse({ id: Number(req.params.id) });
    await db.delete(blogPostsTable).where(eq(blogPostsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete blog post" });
  }
});

export default router;
