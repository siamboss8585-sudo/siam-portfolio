import { Router } from "express";
import { db, projectsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  ListProjectsQueryParams,
  CreateProjectBody,
  UpdateProjectParams,
  UpdateProjectBody,
  DeleteProjectParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const query = ListProjectsQueryParams.parse(req.query);
    let projects = await db.select().from(projectsTable).orderBy(desc(projectsTable.createdAt));

    if (query.search) {
      const s = query.search.toLowerCase();
      projects = projects.filter(
        (p) => p.title.toLowerCase().includes(s) || p.description.toLowerCase().includes(s)
      );
    }

    res.json(
      projects.map((p) => ({
        ...p,
        technologies: p.technologies ?? [],
        createdAt: p.createdAt.toISOString(),
      }))
    );
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list projects" });
  }
});

router.post("/", async (req, res) => {
  try {
    const body = CreateProjectBody.parse(req.body);
    const [project] = await db
      .insert(projectsTable)
      .values({
        ...body,
        technologies: body.technologies ?? [],
        featured: body.featured ?? false,
      })
      .returning();
    res.status(201).json({
      ...project,
      technologies: project.technologies ?? [],
      createdAt: project.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create project" });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const { id } = UpdateProjectParams.parse({ id: Number(req.params.id) });
    const body = UpdateProjectBody.parse(req.body);
    const [project] = await db
      .update(projectsTable)
      .set(body)
      .where(eq(projectsTable.id, id))
      .returning();
    if (!project) return res.status(404).json({ error: "Not found" });
    res.json({
      ...project,
      technologies: project.technologies ?? [],
      createdAt: project.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update project" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const { id } = DeleteProjectParams.parse({ id: Number(req.params.id) });
    await db.delete(projectsTable).where(eq(projectsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete project" });
  }
});

export default router;
